import "./styles.css";
import Header from "./component/Header";
import Meme from "./component/Meme";

export default function App() {
  return (
    <div className="App">
      <Header />
      <Meme />
    </div>
  );
}
