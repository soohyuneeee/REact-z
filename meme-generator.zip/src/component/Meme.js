import memesData from "../memesData";
import React from "react";
export default function Meme() {
  const [memeImage, setMemeImage] = React.useState({
    topText: "",
    BottomText: "",
    randomImage: "https://i.imgflip.com/3oevdk.jpg"
  });
  const [allMemeImages, setAllMemeImages] = React.useState([]);
  React.useEffect(() => {
    async function getMemes() {
      const res = await fetch("https://api.imgflip.com/get_memes");
      const data = await res.json();
      setAllMemeImages(data.data.memes);
    }
    getMemes();
  }, []);

  function getMemeImage() {
    const randomNumber = Math.floor(Math.random() * allMemeImages.length);
    setMemeImage((prevMeme) => ({
      ...prevMeme,
      randomImage: allMemeImages[randomNumber].url
    }));
  }
  function handleChange(event) {
    const { name, value } = event.target;
    setMemeImage((prevMeme) => ({
      ...prevMeme,
      [name]: value
    }));
  }
  return (
    <main>
      <div className="form">
        <input
          className="form--input"
          placeholder="Top"
          name="topText"
          value={memeImage.topText}
          onChange={handleChange}
          type="text"
        />

        <input
          className="form--input"
          placeholder="Bottom"
          name="BottomText"
          value={memeImage.BottomText}
          onChange={handleChange}
          type="text"
        />

        <button className="form--button" onClick={getMemeImage}>
          Get a new meme image 🖼
        </button>
      </div>
      <div className="meme">
        <img src={memeImage.randomImage} className="meme-image" />
        <h2 className="meme--text top">{memeImage.topText}</h2>
        <h2 className="meme--text bottom">{memeImage.BottomText}</h2>
      </div>
    </main>
  );
}
